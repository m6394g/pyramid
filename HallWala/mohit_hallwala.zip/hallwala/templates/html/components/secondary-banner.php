<div id="secondary-banner-wrapper">
    <div id="secondary-banner">
        <div class="banner-slider">
            <div class="banner-slider-bg" data-background-img="../images/container-bg1.jpg">
            </div>
          </div>
    </div>
</div>