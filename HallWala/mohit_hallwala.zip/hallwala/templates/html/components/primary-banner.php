<div id="primary-banner-wrapper">
    <div id="primary-banner">
        <div class="banner-slider" data-background-img="../images/container-bg1.jpg">
            <div class="banner-text">
                <h1>Lorem Ipsum Dolor Sit Amet, consectetur adipiscing elit.</h1>
            </div>
          </div>
        <div class="banner-slider"  data-background-img="../images/container-bg2.jpg">
            <div class="banner-text">
                <h1>Proin tristique felis interdum, vehicula ipsum vel.</h1>
            </div>
          </div>
        <div class="banner-slider" data-background-img="../images/container-bg3.jpg">
            <div class="banner-text">
                <h1>Nunc blandit quis justo a volutpat. Etiam ultrices neque.</h1>
            </div>
          </div>
        <div class="banner-slider" data-background-img="../images/container-bg4.jpg">
            <div class="banner-text">
                <h1>Etiam ultrices neque venenatis nibh lobortis, et sollicitudin metus facilisis.</h1>
            </div>
          </div>
    </div>
</div>