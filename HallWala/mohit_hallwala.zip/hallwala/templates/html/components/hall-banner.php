<div id="hall-gallery-container">
	<div id="hall-gallery">
        <a href="#" class="hall-gallery-section">
            <img src="../images/container-bg1.jpg" alt="fruit1"/>
            <img src="../images/container-bg1.jpg" class="desaturated" alt="fruit1"/>
            <span>Apple</span>
        </a>
        <a href="#" class="hall-gallery-section">
            <img src="../images/container-bg2.jpg" alt="fruit2"/>
            <img src="../images/container-bg2.jpg" class="desaturated" alt="fruit1"/>
            <span>Mandarin</span>
        </a>
        <a href="#" class="hall-gallery-section">
            <img src="../images/container-bg3.jpg" alt="fruit3"/>
            <img src="../images/container-bg3.jpg" class="desaturated" alt="fruit1"/>
            <span>Banannas</span>
        </a>
        <a href="#" class="hall-gallery-section">
            <img src="../images/container-bg4.jpg" alt="fruit4"/>
            <img src="../images/container-bg4.jpg" class="desaturated" alt="fruit1"/>
            <span>Cherries</span>
        </a>
        <a href="#" class="hall-gallery-section">
            <img src="../images/holi-one2.jpg" alt="fruit4"/>
            <img src="../images/holi-one2.jpg" class="desaturated" alt="fruit1"/>
            <span>Cherries</span>
        </a>
    </div>
</div>