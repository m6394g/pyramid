<div id="plain-banner-wrapper">
</div>