<div id="hall-gallery-full-wrapper">
    <div id="hall-gallery-full-mask">
    </div>
    <div id="hall-gallery-full-container">
    	<div id="hall-gallery-full-content">
        </div>
        <div id="hall-gallery-full-controls">
        	<a class="cta-link secondary icons-alone" title='close' id="hall-gallery-full-close" href="#"><span class="icons-cancel"></span></a>
        	<a class="cta-link secondary icons-alone" title='prev' id="hall-gallery-full-prev" href="#"><span class="icons-left-open"></span></a>
            <a class="cta-link primary icons-alone" title='next' id="hall-gallery-full-next" href="#"><span class="icons-right-open"></span></a>
        </div>
    </div>
</div>