<div id="footer-wrapper">
	<footer>
        <div id="footer-container">
        	<div id="footer-content">
                <p class="align-left"><a href='#'>Terms of Use</a><a href='#'>Privacy</a><a href='#'>Disclaimer</a><a href='#'>Contact us</a><a href='#'>About Hallwala</a></p>
                <p class="align-right">
                    <a href='#' title="facebook"><span class="icons-facebook-squared"></span></a><a href='#'><span class="icons-twitter-squared"></span></a><a href='#'><span class="icons-pinterest-squared"></span></a><a href='#'><span class="icons-gplus-squared"></span></a>
                </p>
            </div>
        </div>
        <div id="copyright-container">
        	<p>Copyright &copy; 2014 hallwala.com. All rights reserved.</p>
        </div>
    </footer>
</div>