<div id="site-mobile-nav-wrapper">
    <div id="site-mobile-nav-mask" class="on-left">
    </div>
    <div id="hw-site-mobile-nav">
    </div>
    <div id="hw-site-mobile-user">
    </div>
    <div id="hw-site-mobile-search">
    	<div id="hw-site-mobile-search-wrapper">
            <form id="header_search_mobile_form" action="/">
            </form>
        </div>
    </div>
</div>
