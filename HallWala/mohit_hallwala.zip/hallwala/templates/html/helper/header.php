<div id="header-wrapper">
            	<div id="header-bg">
                </div>
                <div id="header-container">
                	<header>
                    	<a href="#" id="site-logo"><img src="../images/site-logo.png" alt="Hallwala"></a>
                        <a href="#" id="header-search"><span class="icons-search"></span><span class="icons-cancel"></span></a>
                    </header>
                </div>
            </div>
