<?php
//	require('search-results-tools.php');
?>
<?php
//	require('hall-gallery-full.php');
?>
<?php
//	require('site-mobile-nav.php');
?>
<span id="hw-responsive-test">
	<span class="hw-responsive desktop" data-device="desktop"></span>
    <span class="hw-responsive tablet" data-device="tablet"></span>
    <span class="hw-responsive mobile" data-device="mobile"></span>
</span>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="../js/jqflot/excanvas.min.js"></script><![endif]-->
<script type="text/javascript" src="../js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui-1.10.4.custom.min.js"></script>
<script type="text/javascript" src="../js/date-functions.js"></script>
<script type="text/javascript" src="../js/jqflot/jquery.flot.js"></script>
<script type="text/javascript" src="../js/jqflot/jquery.flot.axislabels.js"></script>
<script type="text/javascript" src="../js/jqflot/jquery.flot.orderBars.js"></script>
<script type="text/javascript" src="../js/jqflot/jquery.flot.resize.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.multidatespicker.js"></script>
<script type="text/javascript" src="../js/hoverIntent.js"></script>
<script type="text/javascript" src="../js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script type="text/javascript" src="../js/typeahead.bundle.js"></script>
<script type="text/javascript" src="../js/jquery.touchSwipe.min.js"></script>
<script type="text/javascript" src="../js/site-navigation.js"></script>
<script type="text/javascript" src="../js/site-sliders.js"></script>
<script type="text/javascript" src="../js/core.hallwala.js"></script>
<script type="text/javascript" src="../js/search-filters.js"></script>
<script type="text/javascript" src="../js/user-agent-registration.js"></script>
